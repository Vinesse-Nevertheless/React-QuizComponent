from cs50 import get_string

# ask user name and print greeting
name = get_string("What is your name? ")
print(f"hello, {name}")