# Vinesse-Nevertheless CS 50 Python. Readability Problem Set

Please see the Read Me for the c version of this code for instructions.
